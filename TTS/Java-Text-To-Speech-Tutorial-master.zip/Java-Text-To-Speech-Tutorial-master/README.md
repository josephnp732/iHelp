### PS Java 1.8.0_141 ++ Required ! Download Java 8 here : ( https://www.java.com/en/ )

# New tutorials with Google Text To Speech -> https://github.com/goxr3plus/Java-Google-Text-To-Speech

---

# Java Text To Speech tutorial(MaryTTS)

In this tutorial you will create a simple Text To Speech program in Java(required version 8++[you can use also Java 7 but you have to modify some lines)) using open source library MaryTTS.

## The tutorial on youtube
[![Java Text To Speech](http://img.youtube.com/vi/OLKxBorVwk8/0.jpg)](https://www.youtube.com/watch?v=OLKxBorVwk8)
